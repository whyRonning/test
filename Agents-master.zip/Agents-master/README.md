# Agents
Приложение для агентства недвижимости.
На стеке технологий MERN.
Можно опробовать на codeSandbox: https://codesandbox.io/s/anturazh-gl1bv
