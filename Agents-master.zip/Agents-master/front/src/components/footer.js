import React from "react";

const Footer=React.memo(()=>{
  return (
      <footer>
        <span>© Антураж, Агенство недвижимости. 2019-2021.</span>
      </footer>
  );
});

export default Footer;
