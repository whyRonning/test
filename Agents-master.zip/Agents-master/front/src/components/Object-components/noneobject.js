import React from "react";

export const NoneObject =React.memo( () => {
  return (
    <div>
      <div className="Noneobj">
        <h3>Совпадений не найдено</h3>
      </div>
    </div>
  );
});
