import React from "react";

export const NotFound = React.memo(() => {
  return (
    <section className="notFound">
      <h2>Объект не найден или продан</h2>
    </section>
  );
});
